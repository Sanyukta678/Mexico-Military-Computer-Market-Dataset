# Mexico Military Computer Market Dataset

This repository contains a structured dataset extracted from the public report page "Mexico Military Computer Market" by Next Move Strategy Consulting.

## Contents
- `dataset.csv` — summarizing key segments and players (numeric values marked N/A due to inaccessible source).
- `metadata.json` — field descriptions and provenance.
- `README.md` — this file.

## License & Attribution
Derived summary for educational use. Please attribute the original content to Next Move Strategy Consulting.

## Reference README Style
Styled according to: https://github.com/Sanyukta678/immunoglobulin-market-dataset/blob/main/README.md
